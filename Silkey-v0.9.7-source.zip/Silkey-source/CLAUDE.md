Read @AGENTS.md
